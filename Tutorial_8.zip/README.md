# CampusEats Menu Service — CS543 Assignment 8

**Team members:** Add each member's name and roll number here.

Run the project: `npm install` followed by `npm start`, then open `http://localhost:3000`.

## 1. Selected service and routes

We selected the **CampusEats Menu/Catalogue service**.

| Method | Path | Purpose |
|---|---|---|
| GET | `/items` | List all menu items |
| GET | `/items/:id` | Fetch one menu item by ID |
| POST | `/items` | Create a new menu item |

## 2. HTTP status codes

- **200 OK** — menu list or requested menu item returned successfully.
- **201 Created** — a new menu item was created successfully.
- **404 Not Found** — the requested item ID does not exist.
- **422 Unprocessable Content** — required or valid input is missing, such as an empty name or invalid price.

## 3. `req.params`, `req.body`, and `express.json()`

- `req.params.id` is used in `GET /items/:id` to read the ID from the URL path.
- `req.body` is used in `POST /items` to read the new menu item's JSON data sent by the client.
- `express.json()` is middleware that parses an incoming JSON request body and makes the resulting object available as `req.body`. Without this middleware, Express does not automatically parse JSON request bodies.

## Project structure

```text
CampusEats-Assignment-8/
  server.js
  package.json
  README.md
  public/
    index.html
    style.css
```

## Notes

- The menu is stored in an in-memory JavaScript array. Data resets when the server is stopped and restarted.
- `node_modules/` is created by `npm install` and should not be committed to GitHub.
- Add your Google Drive demonstration folder link here after uploading the demo video and before/after screenshots.

**Google Drive demonstration:** Add your shareable folder link here.

**GitHub repository:** Add your repository URL here.
