from flask import Flask, request, jsonify, make_response
from models import Order
from store import OrderStore
from errors import problem
from payments_client import charge_payment

app = Flask(__name__)
store = OrderStore()


def validate_create_order(data):
    if not isinstance(data, dict):
        return "Request body must be a JSON object."
    for field in ("studentId", "items", "deliveryAddressId", "paymentMethodId"):
        if field not in data:
            return f"Missing required field: {field}"
    if not isinstance(data["studentId"], str) or not data["studentId"].strip():
        return "studentId must be a non-empty string."
    if not isinstance(data["items"], list) or not data["items"]:
        return "items must be a non-empty list."
    for item in data["items"]:
        if not isinstance(item, dict) or "itemId" not in item or "quantity" not in item:
            return "Each item must contain itemId and quantity."
        if not isinstance(item["itemId"], str) or not item["itemId"].strip():
            return "itemId must be a non-empty string."
        if not isinstance(item["quantity"], int) or isinstance(item["quantity"], bool) or item["quantity"] < 1:
            return "quantity must be an integer greater than zero."
    for field in ("deliveryAddressId", "paymentMethodId"):
        if not isinstance(data[field], str) or not data[field].strip():
            return f"{field} must be a non-empty string."
    return None


def validate_cancel_order(data):
    if not isinstance(data, dict):
        return "Request body must be a JSON object."
    if "reason" not in data:
        return "Missing required field: reason."
    if not isinstance(data["reason"], str) or not data["reason"].strip():
        return "reason must be a non-empty string."
    return None


@app.post("/orders")
def create_order():
    data = request.get_json(silent=True)
    error = validate_create_order(data)
    if error:
        return problem("https://campuseats.example/problems/malformed-request", "Malformed Request", 400, error)

    key = request.headers.get("Idempotency-Key")
    if not key:
        return problem("https://campuseats.example/problems/missing-idempotency-key", "Missing Idempotency-Key", 400,
                       "Idempotency-Key header is required.")

    existing = store.find_by_idempotency_key(key)
    if existing:
        # A repeated key returns the original representation without charging again.
        if not store.same_request(key, data):
            return problem("https://campuseats.example/problems/idempotency-conflict", "Idempotency Conflict", 409,
                           "The Idempotency-Key was already used with a different request body.")
        response = make_response(jsonify(existing.as_json()), 201)
        response.headers["Location"] = f"/orders/{existing.order_id}"
        return response

    total = sum(item["quantity"] * 10.0 for item in data["items"])
    payment_result = charge_payment(
        payment_url=None,
        order_id=key,
        amount=total,
        currency="INR",
        idempotency_key=key,
    )
    if not payment_result["success"]:
        if payment_result["status"] == 422:
            return problem("https://campuseats.example/problems/payment-declined", "Payment Declined", 422,
                           payment_result["detail"])
        return problem("https://campuseats.example/problems/payment-service-unavailable",
                       "Payment Service Unavailable", 503, payment_result["detail"])

    order = Order(None, data["studentId"], data["items"], data["deliveryAddressId"],
                  data["paymentMethodId"], "PAID", total, key)
    store.create(order, request_data=data)
    response = make_response(jsonify(order.as_json()), 201)
    response.headers["Location"] = f"/orders/{order.order_id}"
    return response


@app.get("/orders/<int:order_id>")
def get_order(order_id):
    order = store.get(order_id)
    if order is None:
        return problem("https://campuseats.example/problems/order-not-found", "Order Not Found", 404,
                       f"Order {order_id} does not exist.")
    return jsonify(order.as_json()), 200


@app.get("/orders")
def list_orders():
    student_id = request.args.get("studentId")
    status = request.args.get("status")
    if status and status not in {"CREATED", "PAID", "CANCELLED"}:
        return problem("https://campuseats.example/problems/invalid-status", "Invalid Status", 400,
                       "status must be CREATED, PAID or CANCELLED.")
    orders = store.list_orders(student_id, status)
    return jsonify({"orders": [o.as_json() for o in orders]}), 200


@app.post("/orders/<int:order_id>/cancellation")
def cancel_order(order_id):
    data = request.get_json(silent=True)
    error = validate_cancel_order(data)
    if error:
        return problem("https://campuseats.example/problems/malformed-request", "Malformed Request", 400, error)
    order = store.get(order_id)
    if order is None:
        return problem("https://campuseats.example/problems/order-not-found", "Order Not Found", 404,
                       f"Order {order_id} does not exist.")
    if order.status == "CANCELLED":
        return problem("https://campuseats.example/problems/order-state-conflict", "Order State Conflict", 409,
                       "The order has already been cancelled.")
    if order.status != "PAID":
        return problem("https://campuseats.example/problems/order-cannot-be-cancelled", "Order Cannot Be Cancelled", 422,
                       "The order cannot be cancelled in its current state.")
    order.status = "CANCELLED"
    store.update(order)
    return jsonify(order.as_json()), 200


if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5000, debug=False)
