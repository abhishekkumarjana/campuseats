import json


class OrderStore:
    def __init__(self):
        self.orders = {}
        self.idempotency_keys = {}
        self.request_fingerprints = {}
        self.next_id = 1

    def create(self, order, request_data=None):
        order.order_id = self.next_id
        self.next_id += 1
        self.orders[order.order_id] = order
        if order.idempotency_key:
            self.idempotency_keys[order.idempotency_key] = order.order_id
            self.request_fingerprints[order.idempotency_key] = json.dumps(request_data or {}, sort_keys=True)
        return order

    def get(self, order_id):
        return self.orders.get(order_id)

    def find_by_idempotency_key(self, key):
        order_id = self.idempotency_keys.get(key)
        return self.orders.get(order_id) if order_id is not None else None

    def same_request(self, key, request_data):
        return self.request_fingerprints.get(key) == json.dumps(request_data, sort_keys=True)

    def list_orders(self, student_id=None, status=None):
        result = list(self.orders.values())
        if student_id:
            result = [o for o in result if o.student_id == student_id]
        if status:
            result = [o for o in result if o.status == status]
        return result

    def update(self, order):
        self.orders[order.order_id] = order
        return order
