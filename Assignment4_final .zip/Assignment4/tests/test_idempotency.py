from _all_tests import client, order_body, store

def test_idempotent_repeat_returns_original(client):
    headers = {'Idempotency-Key': 'key-002'}
    first = client.post('/orders', json=order_body(), headers=headers)
    second = client.post('/orders', json=order_body(), headers=headers)
    assert first.status_code == second.status_code == 201
    assert first.get_json() == second.get_json()
    assert first.headers['Location'] == second.headers['Location']
    assert len(store.orders) == 1
