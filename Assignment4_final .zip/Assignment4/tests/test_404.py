from _all_tests import client

def test_unknown_order_returns_404(client):
    response = client.get('/orders/999')
    assert response.status_code == 404
    body = response.get_json()
    assert body['title'] == 'Order Not Found'
    assert body['status'] == 404
