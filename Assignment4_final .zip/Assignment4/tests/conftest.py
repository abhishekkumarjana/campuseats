import pytest
from app import app, store

@pytest.fixture(autouse=True)
def reset_store():
    store.orders.clear()
    store.idempotency_keys.clear()
    store.request_fingerprints.clear()
    store.next_id = 1

@pytest.fixture
def client(monkeypatch):
    monkeypatch.setattr('app.charge_payment', lambda *args, **kwargs: {
        'success': True, 'status': 200, 'detail': 'Payment successful.'
    })
    app.config['TESTING'] = True
    with app.test_client() as client:
        yield client

def order_body():
    return {
        'studentId': 'student-101',
        'items': [{'itemId': 'item-1', 'quantity': 2}],
        'deliveryAddressId': 'address-1',
        'paymentMethodId': 'card-1',
    }
