from _all_tests import client, order_body

def test_create_order_success(client):
    response = client.post('/orders', json=order_body(), headers={'Idempotency-Key': 'key-001'})
    assert response.status_code == 201
    assert response.headers['Location'] == '/orders/1'
