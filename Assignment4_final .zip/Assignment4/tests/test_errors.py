from _all_tests import client, order_body

def test_malformed_body_returns_400(client):
    response = client.post('/orders', json={'studentId': 'student-101'}, headers={'Idempotency-Key': 'key-003'})
    assert response.status_code == 400
    body = response.get_json()
    assert set(('type', 'title', 'status', 'detail')) <= body.keys()
    assert body['status'] == 400

def test_cancellation_state_conflict_returns_409(client):
    created = client.post('/orders', json=order_body(), headers={'Idempotency-Key': 'key-004'})
    assert created.status_code == 201
    assert client.post('/orders/1/cancellation', json={'reason': 'Changed mind'}).status_code == 200
    conflict = client.post('/orders/1/cancellation', json={'reason': 'Again'})
    assert conflict.status_code == 409
    assert conflict.get_json()['status'] == 409
