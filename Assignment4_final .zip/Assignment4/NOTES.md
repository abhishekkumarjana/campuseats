# CS543 Web Services — Assignment 4
## CampusEats Orders REST Service

### Team Members

| No. | Name | Roll No. |
|---:|---|---|
| 1 | Abhishek Kumar Jana | 20252651002 |
| 2 | Tushar Bhardwaj | 20252651058 |
| 3 | Ashish Kumar Singh | 20252651014 |
| 4 | Bikash Pradhan | 20252651015 |

**Team/Group:** 2

> The assignment requires the Name/Roll list on the first page of the submission notes and requires the service folder, curl transcript, validator output, and pytest output.

---

# Part A — Model the Service

## A1. Chosen Service

**Orders** is the selected CampusEats service. Payments remains a separate service; Orders calls it over HTTP when a new order requires payment processing.

## A2. SOAP-style Operations

The operations that could have been written in SOAP style are:

1. `placeOrder(studentId, items, deliveryAddressId, paymentMethodId)`
2. `getOrder(orderId)`
3. `listOrders(studentId, status)`
4. `cancelOrder(orderId, reason)`

These are only the starting operations. The REST design below models durable nouns rather than SOAP-style verbs.

## A3. Resource Nouns

- `orders` — the durable order resource.
- `cancellation` — a state-changing sub-resource associated with an order.

No verb such as `get`, `add`, or `cancel` is used in a URL.

## A4. REST Resource Table

| Method | URL | What it does | Success code | Failure codes |
|---|---|---|---|---|
| POST | `/orders` | Creates an order and charges the payment service | 201 | 400, 409, 422, 503 |
| GET | `/orders/{orderId}` | Returns one order | 200 | 404 |
| GET | `/orders?studentId=...&status=...` | Returns orders filtered by query parameters | 200 | 400 |
| POST | `/orders/{orderId}/cancellation` | Changes a paid order to cancelled | 200 | 400, 404, 409, 422 |

The fourth row is deliberately a sub-resource, as required by the assignment.

## A5. Hard Resource-Mapping Choice

The least comfortable mapping was `cancelOrder(orderId, reason)`. Instead of exposing a verb-based URL such as `/orders/{id}/cancel`, the design uses `/orders/{id}/cancellation`. This treats cancellation as a state-changing sub-resource associated with an existing order. We rejected `/cancelOrder` and `/cancel` because the URL should identify a resource, while the HTTP method expresses the requested state change.

---

# Part B — OpenAPI Contract

`openapi.yaml` is written first and contains `info`, `servers`, all four paths, reusable schemas, parameters, headers, reusable responses, and documented failure responses. Request/response schemas are defined once under `components.schemas` and referenced with `$ref`, following the assignment requirements.

### Local YAML structural check

**OpenAPI validation evidence:** The official `openapi-spec-validator` check was run successfully. The validation screenshot shows `openapi.yaml: OK`.

The submission also includes `validate_openapi.py`, which checks the required OpenAPI top-level fields, four paths, reusable schemas, `$ref` usage, and documented failure responses.

**OpenAPI file:** 233 lines.

**Official validation command used:**

```bash
python -m openapi_spec_validator openapi.yaml
```

or paste `openapi.yaml` into Swagger Editor and confirm **0 errors** before final upload.

---

# Part C — Implementation

The service follows the requested structure: `models.py`, `store.py`, `errors.py`, `app.py`, and `tests/`. The model stores the internal payment-method field, while `as_json()` intentionally does not publish it. This keeps the stored record different from the public representation and avoids exposing unnecessary internal information.

### Endpoint behaviour

- `POST /orders` → `201` and `Location` header.
- Repeated `POST /orders` with the same `Idempotency-Key` → original `201` result without a second payment call.
- Reusing the same key with a different body → `409` idempotency conflict.
- `GET /orders/{id}` → `200` or `404`.
- Filtered `GET /orders` → `200`; invalid status → `400`.
- `POST /orders/{id}/cancellation` → `200`; repeated cancellation → `409`; invalid domain state → `422`.
- Every failure uses the same `problem()` shape: `type`, `title`, `status`, `detail`.

These choices implement the status-code and single-error-shape requirements.

## Four automated tests

`tests/test_orders.py` contains tests for:

1. successful creation with `201` and `Location`;
2. idempotent repeat returning the original result;
3. malformed request returning `400`;
4. unknown order returning `404`.

An additional test verifies the required `409` state conflict after cancelling an order twice.

---

# Part D — Surviving the Network

## D1. Outbound Payments Call

Orders calls the Payments service at:

```text
${PAYMENTS_URL}/payments
```

The address is read from the `PAYMENTS_URL` environment variable; it is not hard-coded. The local demonstration Payments service listens on port 5001.

## D2. Timeout, Retry, Backoff and Jitter

The HTTP request uses a **2-second timeout**. Transient 5xx responses and network exceptions are retried up to three total attempts. The delay uses exponential backoff:

```text
0.2 × 2^attempt + random jitter
```

4xx responses are returned immediately and are never retried. The payment create request carries the same `Idempotency-Key` on every attempt, so a retry cannot accidentally become a second payment operation. These choices match the assignment's network-hardening rules.

## D3. Fallback Reasoning

If Payments is unreachable after the retry limit, Orders returns `503 Payment Service Unavailable` and does not create the order as paid. This is safer than degrading to a fake success because an order marked `PAID` without confirmation could leave the order and payment states inconsistent. The client can retry the complete operation using the same idempotency key after the dependency recovers.

---

# Assignment 3 → Assignment 4 Comparison

## 1. WSDL vs OpenAPI line count

The Assignment 3 WSDL itself was not included in the provided Assignment 4 project archive, so its exact line count cannot be measured without inventing a number. The Assignment 4 OpenAPI contract is **233 lines**.

Run this command against the exact WSDL submitted for Assignment 3 to obtain the required number:

```bash
wc -l path/to/your/assignment3.wsdl
wc -l orders/openapi.yaml
```

The difference is primarily due to the protocol models: WSDL describes SOAP messages, operations, bindings, and service/port details, while OpenAPI describes HTTP resources, methods, parameters, schemas, and HTTP responses.

Two things a SOAP WSDL declares that this OpenAPI contract does not need are:

1. SOAP binding/transport details such as the SOAP binding and SOAPAction.
2. SOAP message/envelope-oriented operation definitions.

The assignment explicitly asks for this comparison and the two WSDL-only concepts.

## 2. SOAP Fault → REST Problem Response

A representative Assignment 3 payment fault is:

```xml
<soap:Fault>
  <faultcode>soap:Client</faultcode>
  <faultstring>Payment was declined</faultstring>
  <detail>
    <pay:PaymentError>
      <pay:errorCode>card_declined</pay:errorCode>
      <pay:errorMessage>The payment card was declined.</pay:errorMessage>
    </pay:PaymentError>
  </detail>
</soap:Fault>
```

In the REST service it becomes **HTTP 422** with the common problem shape:

```json
{
  "type": "https://campuseats.example/problems/payment-declined",
  "title": "Payment Declined",
  "status": 422,
  "detail": "The payment card was declined."
}
```

Returning a domain failure inside `200 OK` is a problem because intermediaries, clients, monitoring systems, caches, and generic HTTP tooling interpret `200` as successful processing. The HTTP status should communicate the failure at the network boundary so the client does not need to inspect application payloads to discover that the operation failed.

## 3. UDDI: Publish, Find, Bind

The three conceptual moves still exist, but their mechanism has changed:

- **Publish:** the service contract is published as `openapi.yaml` in the repository/API documentation.
- **Find:** consumers can discover the API through its repository, documentation, or API catalogue.
- **Bind:** the consumer uses the HTTP endpoint described by OpenAPI and sends normal HTTP requests.

A separate UDDI server is no longer required. The API repository/catalogue and OpenAPI document take over most of the discovery/documentation role.

## 4. XML Schema vs Hand Validation

The specific function carrying the XML Schema responsibility in this implementation is:

```text
validate_create_order(data)
```

and for cancellation:

```text
validate_cancel_order(data)
```

They are called before request fields are used. Without this validation, a request such as `{"studentId":"student-101"}` could reach the handler and cause missing-field errors or inconsistent processing instead of a controlled `400` response.

## 5. Where SOAP Would Still Be Preferred

I would still choose SOAP for a strongly governed payment or financial partner where message-level security and a strict enterprise contract are required. The guarantee being purchased is a formal message contract plus SOAP-level security/transaction features that are useful for regulated, multi-party enterprise integration. For the CampusEats student-facing CRUD resources, REST is simpler and better suited to ordinary HTTP clients.

---

# Curl Transcript

The following commands are the exact required scenarios. Run them after starting the included Payments service and Orders service. The expected status sequence is **201, 201, 400, 404, 200, 409**.

```bash
# Terminal 1
cd payments
python app.py

# Terminal 2
cd orders
# Linux/macOS:
export PAYMENTS_URL=http://127.0.0.1:5001
python app.py

# Terminal 3
curl -i -X POST http://127.0.0.1:5000/orders \
  -H 'Content-Type: application/json' \
  -H 'Idempotency-Key: demo-001' \
  -d '{"studentId":"student-101","items":[{"itemId":"item-1","quantity":2}],"deliveryAddressId":"address-1","paymentMethodId":"card-1"}'

curl -i -X POST http://127.0.0.1:5000/orders \
  -H 'Content-Type: application/json' \
  -H 'Idempotency-Key: demo-001' \
  -d '{"studentId":"student-101","items":[{"itemId":"item-1","quantity":2}],"deliveryAddressId":"address-1","paymentMethodId":"card-1"}'

curl -i -X POST http://127.0.0.1:5000/orders \
  -H 'Content-Type: application/json' \
  -H 'Idempotency-Key: demo-002' \
  -d '{"studentId":"student-101"}'

curl -i http://127.0.0.1:5000/orders/999

curl -i -X POST http://127.0.0.1:5000/orders/1/cancellation \
  -H 'Content-Type: application/json' \
  -d '{"reason":"Changed mind"}'

curl -i -X POST http://127.0.0.1:5000/orders/1/cancellation \
  -H 'Content-Type: application/json' \
  -d '{"reason":"Again"}'
```

The `curl_transcript.txt` file contains the required commands and expected status sequence. Run them locally with the services running, replace the checklist with the actual `-i` HTTP output, and include a screenshot of the terminal output in the `evidence/` folder. Do not fabricate the HTTP output.

---

# Pytest

Run:

```bash
cd orders
pytest -q
```

Expected result:

```text
5 passed
```

The test suite is included and ready to run in the normal lab environment. The final submission should include a screenshot of the successful `pytest -q` run in the `evidence/` folder.

---

# Submission Checklist

- [x] `orders/openapi.yaml`
- [x] `orders/app.py`
- [x] `orders/models.py`
- [x] `orders/store.py`
- [x] `orders/errors.py`
- [x] `orders/payments_client.py`
- [x] `orders/tests/test_orders.py`
- [x] `orders/requirements.txt`
- [x] `orders/validate_openapi.py`
- [x] `orders/curl_transcript.txt`
- [x] Complete `NOTES.md`
- [x] Corrected Bikash Pradhan roll number: **20252651015**
- [x] No `venv/`, `__pycache__/`, or `.pytest_cache/` in the ZIP
- [x] Run the official OpenAPI validator and retain its zero-error output in `evidence/openapi_validation.jpg`
- [ ] Run `pytest -q` and retain the passing output in `evidence/pytest.png`
- [ ] Run the curl commands with `-i` and retain the live output in `orders/curl_transcript.txt` and `evidence/curl_output.png`

The assignment's required submission items and evidence are summarized directly from the Assignment 4 brief.
