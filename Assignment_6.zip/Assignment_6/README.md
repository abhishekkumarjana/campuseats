# CampusEats Assignment 6 — Orders Service

Implements the Assignment 6 themes: HTTP statuses, Problem Details errors, field-level validation, content negotiation, and curl evidence.

## Run
```bash
python -m venv .venv
# Windows Git Bash:
source .venv/Scripts/activate
# Linux/macOS:
source .venv/bin/activate
pip install -r requirements.txt
uvicorn app:app --reload
```

In another terminal:
```bash
pytest -q
```

