# Assignment 6 Notes

## 1. Status map
- `POST /orders`: `201 Created` when created; `400` for malformed JSON; `406` for unsupported Accept; `422` for invalid fields.
- `GET /orders`: `200 OK`; `406` if requested representation is unsupported.
- `GET /orders/{id}`: `200 OK`; `404` if the order does not exist; `406` if requested representation is unsupported.
- `PATCH /orders/{id}`: `200 OK` after a valid status transition; `400` for malformed JSON; `404` for unknown order; `409` for illegal transition.
- `DELETE /orders/{id}`: `204 No Content` after deletion; `404` for unknown order; `409` if order cannot be deleted.
- `POST /admin/rate-limit-test`: `429 Too Many Requests`; includes `Retry-After: 10`.

## 2. Problem type catalogue
- `invalid-json`: request body is not valid JSON.
- `validation-error`: one or more order fields fail validation.
- `order-not-found`: the requested order ID does not exist.
- `illegal-transition`: requested order status transition is not permitted.
- `not-acceptable`: the service cannot produce the requested response format.
- `rate-limited`: client has exceeded the rate limit.

Assignment brief also names `empty-cart`, `item-unavailable`, and `payment-declined`. Add these when the A5 order flow integrates catalogue/payment checks. The starter service does not simulate those external services.

## 3. Example Problem Details body
```json
{
  "type": "order-not-found",
  "title": "Order Not Found",
  "status": 404,
  "detail": "No order exists with that identifier."
}
```
- `type`: stable machine-readable error identifier.
- `title`: short human-readable summary.
- `status`: HTTP status code.
- `detail`: safe explanation for the caller.

## 4. Field-level 422 with two or more errors
Example request:
```json
{"items":[{"name":"","qty":0}],"address":""}
```
The response is `422 Unprocessable Content` and its `errors` array identifies invalid `items[0].name`, `items[0].qty`, and `address`.

## 5. Retry safety
- `GET` requests are safe to retry.
- `POST /orders` is not automatically safe to retry unless an idempotency key is implemented (carry forward Assignment 5's idempotency behavior).
- `PATCH` and `DELETE` should only be retried when the client can determine the first request's outcome or the operation is designed to be idempotent.
- `429` and `503` responses should include `Retry-After`; retry only after that delay and only for transient failures. Do not blindly retry unchanged `4xx` requests.

## 6. Internal error mapping
Risky parsing and validation paths return clean `400`/`422` responses. Do not expose exception traces, database errors, credentials, or internal paths. In a production version, wrap catalogue/payment calls and storage operations in `try/except`, log the exception server-side, and map it to a safe `500` Problem Details response.

## 7. JSON and XML negotiation
Send `Accept: application/json` for JSON and `Accept: application/xml` for XML. Unsupported values such as `Accept: text/csv` return `406 Not Acceptable`.

## Important integration note
This is a runnable starter based on the Assignment 6 PDF, not a replacement for your exact Assignment 5 repository. Before submission, merge these behaviors into your existing A5 Orders service and preserve its idempotency, timeout, retry/backoff, and real downstream-call tests.
