from fastapi.testclient import TestClient
from app import app, orders

client = TestClient(app)

def setup_function():
    orders.clear()

def test_create_returns_201_and_location():
    r = client.post("/orders", json={"items": [{"name": "Dosa", "qty": 2}], "address": "Hostel A"})
    assert r.status_code == 201
    assert r.headers["location"].startswith("/orders/")
    assert r.json()["status"] == "pending"

def test_validation_collects_multiple_errors():
    r = client.post("/orders", json={"items": [{"name": "", "qty": 0}], "address": ""})
    assert r.status_code == 422
    assert r.headers["content-type"].startswith("application/problem+json")
    assert len(r.json()["errors"]) >= 3

def test_unknown_order_is_problem_404():
    r = client.get("/orders/not-real")
    assert r.status_code == 404
    assert r.json()["type"] == "order-not-found"

def test_illegal_transition_is_409():
    r = client.post("/orders", json={"items": [{"name": "Dosa", "qty": 1}], "address": "Hostel A"})
    order_id = r.json()["id"]
    patch = client.patch(f"/orders/{order_id}", json={"status": "completed"})
    assert patch.status_code == 409
    assert patch.json()["type"] == "illegal-transition"

def test_xml_negotiation():
    r = client.post("/orders", headers={"Accept": "application/xml"},
                    json={"items": [{"name": "Dosa", "qty": 1}], "address": "Hostel A"})
    assert r.status_code == 201
    assert r.headers["content-type"].startswith("application/xml")
    assert "<order>" in r.text

def test_unsupported_accept():
    r = client.get("/orders", headers={"Accept": "text/csv"})
    assert r.status_code == 406
