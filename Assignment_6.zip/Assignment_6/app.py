from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse, Response
from pydantic import BaseModel
from typing import Optional
from uuid import uuid4
from datetime import datetime, timezone
import logging
import time

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("campuseats.orders")
app = FastAPI(title="CampusEats Orders Service", version="1.0.0")

orders = {}
rate_limit_until = 0

class OrderItem(BaseModel):
    name: str
    qty: int

class OrderBody(BaseModel):
    items: list[dict]
    address: str

def problem(status: int, title: str, detail: str, type_: str, errors=None, headers=None):
    body = {"type": type_, "title": title, "status": status, "detail": detail}
    if errors is not None:
        body["errors"] = errors
    return JSONResponse(body, status_code=status, media_type="application/problem+json",
                        headers=headers or {})

def wants_xml(request: Request):
    accept = request.headers.get("accept", "application/json")
    if "application/xml" in accept and "application/json" not in accept:
        return True
    if "*/*" in accept or "application/json" in accept:
        return False
    return None

def render_order(request: Request, order: dict, status_code=200, headers=None):
    fmt = wants_xml(request)
    if fmt is None:
        return problem(406, "Not Acceptable", "Supported formats are application/json and application/xml.",
                       "not-acceptable", headers=headers)
    if fmt:
        body = (f'<order><id>{order["id"]}</id><status>{order["status"]}</status>'
                f'<address>{order["address"]}</address><items>')
        for item in order["items"]:
            body += f'<item><name>{item["name"]}</name><qty>{item["qty"]}</qty></item>'
        body += '</items></order>'
        return Response(body, status_code=status_code, media_type="application/xml",
                        headers=headers or {})
    return JSONResponse(order, status_code=status_code, headers=headers or {})

def validate_order(payload):
    errors = []
    if not isinstance(payload, dict):
        return [{"field": "body", "message": "Must be a JSON object."}]
    items = payload.get("items")
    if not isinstance(items, list) or len(items) == 0:
        errors.append({"field": "items", "message": "Must be a non-empty array."})
    elif isinstance(items, list):
        for i, item in enumerate(items):
            if not isinstance(item, dict):
                errors.append({"field": f"items[{i}]", "message": "Must be an object."})
                continue
            if not isinstance(item.get("name"), str) or not item.get("name", "").strip():
                errors.append({"field": f"items[{i}].name", "message": "Must be a non-empty string."})
            qty = item.get("qty")
            if isinstance(qty, bool) or not isinstance(qty, int) or qty < 1:
                errors.append({"field": f"items[{i}].qty", "message": "Must be an integer greater than or equal to 1."})
    if not isinstance(payload.get("address"), str) or not payload.get("address", "").strip():
        errors.append({"field": "address", "message": "Is required and must be a non-empty string."})
    return errors

@app.middleware("http")
async def response_content_type_charset(request: Request, call_next):
    response = await call_next(request)
    ct = response.headers.get("content-type", "")
    if ct and "charset=" not in ct and (ct.startswith("application/json") or ct.startswith("application/problem+json") or ct.startswith("application/xml") or ct.startswith("text/")):
        response.headers["content-type"] = ct + "; charset=utf-8"
    return response

@app.get("/health")
def health():
    return {"status": "ok"}

@app.post("/orders")
async def create_order(request: Request):
    try:
        payload = await request.json()
    except Exception:
        return problem(400, "Bad Request", "Request body must contain valid JSON.", "invalid-json")
    errors = validate_order(payload)
    if errors:
        return problem(422, "Validation Failed", "One or more fields are invalid.", "validation-error", errors)
    order_id = str(uuid4())
    order = {
        "id": order_id,
        "items": payload["items"],
        "address": payload["address"],
        "status": "pending",
        "created_at": datetime.now(timezone.utc).isoformat()
    }
    orders[order_id] = order
    return render_order(request, order, 201, {"Location": f"/orders/{order_id}"})

@app.get("/orders")
async def list_orders(request: Request):
    return render_order(request, {"orders": list(orders.values())})

@app.get("/orders/{order_id}")
async def get_order(order_id: str, request: Request):
    order = orders.get(order_id)
    if not order:
        return problem(404, "Order Not Found", "No order exists with that identifier.", "order-not-found")
    return render_order(request, order)

@app.patch("/orders/{order_id}")
async def update_order(order_id: str, request: Request):
    order = orders.get(order_id)
    if not order:
        return problem(404, "Order Not Found", "No order exists with that identifier.", "order-not-found")
    try:
        payload = await request.json()
    except Exception:
        return problem(400, "Bad Request", "Request body must contain valid JSON.", "invalid-json")
    new_status = payload.get("status") if isinstance(payload, dict) else None
    allowed = {"pending": {"confirmed", "cancelled"}, "confirmed": {"preparing", "cancelled"},
               "preparing": {"ready"}, "ready": {"completed"}}
    if new_status not in allowed.get(order["status"], set()):
        return problem(409, "Illegal Transition", f"Cannot change status from {order['status']} to {new_status}.",
                       "illegal-transition")
    order["status"] = new_status
    return render_order(request, order)

@app.delete("/orders/{order_id}")
async def delete_order(order_id: str):
    order = orders.get(order_id)
    if not order:
        return problem(404, "Order Not Found", "No order exists with that identifier.", "order-not-found")
    if order["status"] not in {"pending", "cancelled"}:
        return problem(409, "Illegal Transition", "Only pending or cancelled orders can be deleted.",
                       "illegal-transition")
    del orders[order_id]
    return Response(status_code=204, headers={"Content-Type": "application/json; charset=utf-8"})

@app.post("/admin/rate-limit-test")
def rate_limit_test():
    return problem(429, "Too Many Requests", "Rate limit test endpoint.", "rate-limited",
                   headers={"Retry-After": "10"})
