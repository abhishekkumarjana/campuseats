const express = require("express");
const path = require("path");

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware: parse incoming JSON and serve the front-end files.
app.use(express.json());
app.use(express.static(path.join(__dirname, "public")));

// In-memory data source (resets whenever the server restarts).
let items = [
  { id: 1, name: "Veg Burger", price: 70, available: true },
  { id: 2, name: "Masala Dosa", price: 90, available: true },
  { id: 3, name: "Paneer Sandwich", price: 110, available: false },
  { id: 4, name: "Cold Coffee", price: 60, available: true }
];

let nextId = 5;

// GET /items — return all menu items.
app.get("/items", (req, res) => {
  res.status(200).json(items);
});

// GET /items/:id — return one item, or 404 when it does not exist.
app.get("/items/:id", (req, res) => {
  const id = Number(req.params.id);

  if (!Number.isInteger(id) || id <= 0) {
    return res.status(404).json({ error: "Item not found" });
  }

  const item = items.find((currentItem) => currentItem.id === id);

  if (!item) {
    return res.status(404).json({ error: "Item not found" });
  }

  return res.status(200).json(item);
});

// POST /items — validate and create a new menu item.
app.post("/items", (req, res) => {
  const { name, price, available = true } = req.body || {};

  if (
    typeof name !== "string" ||
    name.trim() === "" ||
    price === undefined ||
    price === null ||
    price === "" ||
    !Number.isFinite(Number(price)) ||
    Number(price) < 0
  ) {
    return res.status(422).json({
      error: "A non-empty name and a valid non-negative price are required."
    });
  }

  if (typeof available !== "boolean") {
    return res.status(422).json({
      error: "The available field must be true or false."
    });
  }

  const newItem = {
    id: nextId++,
    name: name.trim(),
    price: Number(price),
    available
  };

  items.push(newItem);
  return res.status(201).json(newItem);
});

// A clear JSON response for unknown API routes.
app.use("/items", (req, res) => {
  res.status(404).json({ error: "API route not found" });
});

app.listen(PORT, () => {
  console.log(`CampusEats API is running at http://localhost:${PORT}`);
});
