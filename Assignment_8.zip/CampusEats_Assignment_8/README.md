# CampusEats — Menu Service (Assignment 8)

**Team members:**
    Abhishek Kumar Jana - 20252651002
    Bikash Pradhan - 20252651015
    Ashish Kumar Singh - 20252651014
    Tushar Bharadwaj - 20252651058

## 1. Service and routes

We selected the **CampusEats Menu/Catalogue service**. It manages food items available on campus.

| HTTP method | Path | Purpose |
| GET | `/items` | List all menu items |
| GET | `/items/:id` | Fetch one menu item by its ID |
| POST | `/items` | Create a new menu item |

## 2. HTTP status codes

- **200 OK** — the list or requested item was returned successfully.
- **201 Created** — a new menu item was created successfully.
- **404 Not Found** — the requested item ID does not exist (or the ID is invalid).
- **422 Unprocessable Content** — required input is missing or invalid, such as an empty name or an invalid price.

## 3. Use of `req.params`, `req.body`, and `express.json()`

- `req.params.id` is used in `GET /items/:id` to read the item ID from the URL path.
- `req.body` is used in `POST /items` to read the new menu item's JSON data sent by the client.
- `express.json()` is middleware that parses a JSON request body and makes the resulting JavaScript object available as `req.body`. Without it, Express does not automatically parse incoming JSON payloads.

## How to run

1. Install [Node.js](https://nodejs.org/) (LTS version).

2. Open a terminal in the project folder.

3. Install dependencies:

   npm install

4. Start the server:

   npm start

5. Open `http://localhost:3000` in your browser.

The application uses an in-memory array. New items remain available while the server is running, but the data resets to the four seed records when the server restarts.

## Demo and submission checklist

**Google Drive demo link:** 
      https://drive.google.com/drive/folders/1nDb_oztJtWf1jk3TuMXoVo6IE5ab1KCg

**GitHub repository:** 
      git@github.com:abhishekkumarjana/campuseats.git
