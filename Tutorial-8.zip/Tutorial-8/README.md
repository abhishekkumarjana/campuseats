# CampusEats Catalogue

A simple menu catalogue created for CS543 Web Services using **Node.js** and **Express**. You can view the menu in your browser and add new items through a form connected to a REST API.

## Run the project

You need Node.js (version 18 or later).

1. Open this folder in VS Code.
2. Open the terminal in the project folder.
3. Install the required package:

   ```bash
   npm install
   ```

4. Start the application:

   ```bash
   npm start
   ```

5. Visit **http://localhost:3000** in your browser.

## API endpoints

| Method | Endpoint | What it does |
|---|---|---|
| `GET` | `/items` | Displays all menu items as JSON. |
| `GET` | `/items/:id` | Returns a menu item by its ID. |
| `POST` | `/items` | Adds a new menu item. |

### Example POST request

Send a JSON body with the item details:

```json
{
  "name": "Masala Dosa",
  "price": 60,
  "available": true
}
```

## HTTP status codes

- `200 OK` – the requested menu data was returned successfully.
- `201 Created` – the new menu item was added.
- `404 Not Found` – the requested item ID does not exist.
- `422 Unprocessable Content` – the submitted item details are invalid.

## Project structure

```text
CampusEats/
├── public/
│   ├── index.html
│   └── style.css
├── server.js
├── package.json
└── README.md
```

## How the application works

When the page opens, it requests the menu using `GET /items`. To add an item, fill in the form and submit it. The page sends the details as JSON using `POST /items`, and the updated menu appears in the list.

For this tutorial, menu data is stored in memory. This means newly added items are cleared when the server is stopped or restarted.

## Submission links

- **GitHub repository:** Add your repository link here.
- **Demonstration video and screenshots:** Add your Google Drive link here if these are required in your submission instructions.
