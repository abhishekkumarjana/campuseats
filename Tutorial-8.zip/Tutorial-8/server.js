const express = require('express');
const app = express();

app.use(express.json());             // read JSON request bodies
app.use(express.static('public'));   // serve the web page

let items = [
  { id: 1, name: 'Veg Burger', price: 70, available: true },
  { id: 2, name: 'Masala Dosa', price: 90, available: true },
  { id: 3, name: 'Paneer Sandwich', price: 110, available: false },
  { id: 4, name: 'Cold Coffee', price: 60, available: true }
];
let nextId = 5;

app.get('/items', (req, res) => {
  res.status(200).json(items);
});

app.get('/items/:id', (req, res) => {
  const item = items.find(i => i.id === Number(req.params.id));
  if (!item) return res.status(404).json({ error: 'item not found' });
  res.status(200).json(item);
});

app.post('/items', (req, res) => {
  const { name, price, available = true } = req.body || {};

  if (!name || typeof name !== 'string' || !name.trim()) {
    return res.status(422).json({ error: 'name required' });
  }
  if (price === undefined || price === null || price === '' ||
      !Number.isFinite(Number(price)) || Number(price) < 0) {
    return res.status(422).json({ error: 'valid non-negative price required' });
  }
  if (typeof available !== 'boolean') {
    return res.status(422).json({ error: 'available must be true or false' });
  }

  const item = {
    id: nextId++,
    name: name.trim(),
    price: Number(price),
    available
  };
  items.push(item);
  res.status(201).json(item);
});

app.listen(3000, () => {
  console.log('CampusEats on http://localhost:3000');
});
